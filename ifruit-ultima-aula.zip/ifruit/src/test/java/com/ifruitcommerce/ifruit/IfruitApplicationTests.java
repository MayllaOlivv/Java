package com.ifruitcommerce.ifruit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IfruitApplicationTests {

	@Test
	void contextLoads() {
	}

}
