package com.ifruitcommerce.ifruit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IfruitApplication {

	public static void main(String[] args) {
		SpringApplication.run(IfruitApplication.class, args);
	}

}
